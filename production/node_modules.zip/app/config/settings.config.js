module.exports = {
    secret: '50cb92397370b4d3fe9b46056b75c054'
}