// module.exports = {
//   url: "mongodb+srv://mklabsproduction:QJHcdC1fWLUucbZp@cluster0.pq7uu.mongodb.net/mklabs?retryWrites=true&w=majority"
// };

// module.exports = {
//   url: "mongodb+srv://usman:usman@cluster0.0xxv5.mongodb.net/labDB?retryWrites=true&w=majority"
// }

module.exports = {
  url: "mongodb://localhost/mklabs"
};